package tibco.bw.sample.custom.monitoring.api.app.status.subscriber;

import org.osgi.service.event.Event;
import org.osgi.service.event.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tibco.bw.thor.management.model.node.ApplicationRuntimeState;

/**
 * Subscriber to get the state of the application. 
 *This class can be used to behave as subscriber and getting live status of the application 
 *or this subscriber can cache the current state and provide the info when requested for.
 */
public class BWApplicationEventSubscriber implements EventHandler {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	@Override
	public void handleEvent(Event applicationEvent) {
		System.out.println(applicationEvent.toString());
		//This ApplicationRuntimeState Model class gives you the info related to state of the application
		ApplicationRuntimeState state = (ApplicationRuntimeState) applicationEvent
				.getProperty("state");
		logger.info("Application  :" + state.getName() + "Version : "
				+ state.getVersion() + "With Current State as   :"
				+ state.getState()+""+"++++++++++++++++++");
		;
	}

}