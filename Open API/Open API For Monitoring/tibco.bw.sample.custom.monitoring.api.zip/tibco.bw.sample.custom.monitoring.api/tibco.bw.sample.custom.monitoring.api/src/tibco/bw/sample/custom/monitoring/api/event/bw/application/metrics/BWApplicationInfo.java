package tibco.bw.sample.custom.monitoring.api.event.bw.application.metrics;

public class BWApplicationInfo {

}
