package tibco.bw.sample.custom.monitoring.api.pcf.env.info;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

public class PCFENVInfo {

	public static String getInstanceID(){
		JSONObject applicationObject=null;
		String instanceIndex=null;
		if (System.getProperty("bwce.edition") != null) {
			if (isPCF()) {
				String vcap_application = System.getenv("VCAP_APPLICATION");
				try {
					applicationObject = new JSONObject(vcap_application);
				} catch (JSONException e) {
					e.printStackTrace();
				}
				try {	
					 instanceIndex = String.valueOf((Integer) applicationObject.get("instance_index"));
				} catch (JSONException e) {
					e.printStackTrace();
				}
				return instanceIndex;
			}
		}
		return null;
	}
	
	private static boolean isPCF() {
		return System.getenv("VCAP_APPLICATION") != null;
	}
}
