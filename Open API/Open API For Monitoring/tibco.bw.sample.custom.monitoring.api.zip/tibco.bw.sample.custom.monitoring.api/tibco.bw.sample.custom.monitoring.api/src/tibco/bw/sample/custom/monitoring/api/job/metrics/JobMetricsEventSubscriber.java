package tibco.bw.sample.custom.monitoring.api.job.metrics;
import java.util.Timer;
import java.util.TimerTask;

import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.util.tracker.ServiceTrackerCustomizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tibco.bw.frwk.api.AppNodeMetricsProvider;
/**
 * Provides metrics for the Application. 
 *Calling the API's to get the intended info requires a application name and application version
 *Class just needs to be modified to return the data based on the application name and version
 */
public class JobMetricsEventSubscriber implements ServiceTrackerCustomizer<AppNodeMetricsProvider,AppNodeMetricsProvider> {
	
	private final Logger logger = LoggerFactory.getLogger(getClass());
  
	
	private final BundleContext context;
	private AppNodeMetricsProvider service;
	 public JobMetricsEventSubscriber(BundleContext bundleContext) {
		 context = bundleContext;
		
	}
	@Override
	public AppNodeMetricsProvider addingService(
			ServiceReference<AppNodeMetricsProvider> arg0) {
		 service = context.getService(arg0);
		 logger.info("Service for AppnodeMetricsProvider Received");
		 startGettingMetricsForTheJob();
		return service;
		
	}

	@Override
	public void modifiedService(ServiceReference<AppNodeMetricsProvider> arg0,
			AppNodeMetricsProvider arg1) {
		
	}

	@Override
	public void removedService(ServiceReference<AppNodeMetricsProvider> arg0,
			AppNodeMetricsProvider arg1) {
		 context.ungetService(arg0);
		
		
	}
	private void startGettingMetricsForTheJob(){
		TimerTask timerTaskToEnforceJVMShutdown = new TimerTask() {

			@Override
			public void run() {
				logger.info("Running Job Count : "+service.getRunningJobsCount("testActivator.application","1.0")+"    +++++++++");
				logger.info("Created Job Count :"+service.getCreatedJobsCount("testActivator.application","1.0")+"    +++++++++");
				logger.info("Faulted Job Count :"+service.getFaultedJobsCount("testActivator.application","1.0")+"    +++++++++");
				logger.info("PagedOut Job Count  :"+service.getPagedoutJobsCount("testActivator.application","1.0")+"    +++++++++");
				logger.info("Scehuled Job Count :  "+service.getScheduledJobsCount("testActivator.application","1.0")+"    +++++++++");
				logger.info("Cancelled Job Count  :"+service.getCancelledJobsCount("testActivator.application","1.0")+"    +++++++++");
			}
	};
	Timer timerToEnforeJVMShutdown = new Timer(true);
	timerToEnforeJVMShutdown.schedule(timerTaskToEnforceJVMShutdown,120000);
	}
}
