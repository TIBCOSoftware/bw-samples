package tibco.bw.sample.custom.monitoring.api;

import java.util.Hashtable;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.service.event.EventConstants;
import org.osgi.service.event.EventHandler;
import org.osgi.util.tracker.ServiceTracker;

import tibco.bw.sample.custom.monitoring.api.app.status.subscriber.BWApplicationEventSubscriber;
import tibco.bw.sample.custom.monitoring.api.job.metrics.JobMetricsEventSubscriber;
import tibco.bw.sample.custom.monitoring.application.data.ApplicationDataClient;

import com.tibco.bw.frwk.api.AppNodeMetricsProvider;

public class Activator implements BundleActivator {

	private static BundleContext context;
	private static final String APP_STATE_CHANGED_EVENT = "com/tibco/bw/runtime/AppStateChangedEvent";
	private ServiceTracker<AppNodeMetricsProvider, AppNodeMetricsProvider> serviceTracker;

	static BundleContext getContext() {
		return context;
	}

	/*
	 * (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#start(org.osgi.framework.BundleContext)
	 */
	public void start(BundleContext bundleContext) throws Exception {
		Activator.context = bundleContext;
		Hashtable<String, Object> props = new Hashtable<String, Object>();
		props.put(EventConstants.EVENT_TOPIC, APP_STATE_CHANGED_EVENT);
		bundleContext.registerService(EventHandler.class,
				new BWApplicationEventSubscriber(), props);
		JobMetricsEventSubscriber jobSubscriber = new JobMetricsEventSubscriber(
				bundleContext);
		serviceTracker = new ServiceTracker<AppNodeMetricsProvider, AppNodeMetricsProvider>(
				context, AppNodeMetricsProvider.class.getName(), jobSubscriber);
		serviceTracker.open();
		ApplicationDataClient adc = new ApplicationDataClient();
	}

	/*
	 * (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#stop(org.osgi.framework.BundleContext)
	 */
	public void stop(BundleContext bundleContext) throws Exception {
		Activator.context = null;
	}

}
