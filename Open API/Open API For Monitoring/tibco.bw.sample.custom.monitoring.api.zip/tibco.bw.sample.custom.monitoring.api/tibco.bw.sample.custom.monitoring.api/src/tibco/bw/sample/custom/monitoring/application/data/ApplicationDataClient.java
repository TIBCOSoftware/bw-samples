package tibco.bw.sample.custom.monitoring.application.data;

import java.util.Timer;
import java.util.TimerTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tibco.bw.frwk.custom.api.wrappers.application.info.ApplicationRuntimeStateApi;
import com.tibco.bw.thor.management.model.node.ApplicationRuntimeState;
import com.tibco.bw.thor.management.model.node.ConfigProps;
import com.tibco.bw.thor.management.model.node.Endpoint;

/**
 * @author ljoshi
 *
 */
public class ApplicationDataClient {
    //This Field exposes the API to get the info related to Application
	private ApplicationRuntimeStateApi instance;
	private final Logger logger = LoggerFactory.getLogger(getClass());
	public ApplicationDataClient() {
		instance = ApplicationRuntimeStateApi.getInstance();
		showApplicationStatusAndEndpoints(120000);
		showApplicationStatusAndEndpoints(180000);
	}
	
	private void showApplicationStatusAndEndpoints(long time){
		TimerTask timerTaskToEnforceJVMShutdown = new TimerTask() {

			@Override
			public void run() {
				logger.info("Pritning Data for the application :+++++++++++++");
				ApplicationRuntimeState[] list = instance.getApplications().getStates();
				for(ApplicationRuntimeState ars:list){
					logger.info("Name of the application  :"+ars.getName());
					logger.info("Version of the application  :"+ars.getVersion());
					logger.info("Componennts of the application  :"+ars.getComponents());
					logger.info("Endpoints of the aplication  :"+ars.getEndpoints());
					logger.info("Details for the Endpoints  :+++++++++++");
					for(Endpoint ep:ars.getEndpoints()){
						logger.info("Name of the endpoint  : "+ep.getName());
						logger.info("Type of the endpoint   :  "+ep.getType());
						logger.info("URL of the endpoint    : "+ep.getUrl());
					}
					ConfigProps cp = instance.getConfigurations(ars.getName(), ars.getVersion());
					logger.info("Configurations used  for the application   :"+cp);
					
				}
				
			}
	};
	Timer timerToEnforeJVMShutdown = new Timer(true);
	timerToEnforeJVMShutdown.schedule(timerTaskToEnforceJVMShutdown,time);
	}
}
