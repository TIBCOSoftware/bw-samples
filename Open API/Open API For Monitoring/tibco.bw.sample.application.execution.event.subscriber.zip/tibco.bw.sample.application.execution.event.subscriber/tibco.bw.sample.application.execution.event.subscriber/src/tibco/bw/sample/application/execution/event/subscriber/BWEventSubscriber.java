package tibco.bw.sample.application.execution.event.subscriber;

import org.osgi.service.event.Event;
import org.osgi.service.event.EventHandler;

import com.tibco.bw.runtime.AuditEvent;
import com.tibco.bw.runtime.event.ActivityAuditEvent;
import com.tibco.bw.runtime.event.ProcessAuditEvent;
import com.tibco.bw.runtime.event.TransitionAuditEvent;
import com.tibco.bw.runtime.event.State;

// referenced in component.xml
public class BWEventSubscriber implements EventHandler {

	@Override
    public void handleEvent(Event event) {
		AuditEvent auditEvent = (AuditEvent) event.getProperty("eventData");
		if(auditEvent instanceof ProcessAuditEvent) {
			//ProcessInstance data
		    System.out.println(auditEvent.toString());
		} else if(auditEvent instanceof ActivityAuditEvent) {
			//Activity data
		    System.out.println(auditEvent.toString());
		    //Getting Input /Output Schema for the activities
			try {
		    	String[] temp=((ActivityAuditEvent) auditEvent).getSerializedInputData();
		    	
		    	String[] temp1=((ActivityAuditEvent) auditEvent).getSerializedOutputData();
		    	 // The input data would be Null for the Completion state of the activity
		    	if(((ActivityAuditEvent) auditEvent).getActivityState()==State.COMPLETED){
		    			System.out.println("Output data for the completion of the activity : "+((ActivityAuditEvent) auditEvent).getActivityName()+":    "+((temp1 !=null)?temp1[0]: temp1));
		    	// The output data would be Null for the Started State of the activity
		    	}else if(((ActivityAuditEvent) auditEvent).getActivityState()==State.STARTED){
			    		System.out.println("Input data for the starting of the activity : "+((ActivityAuditEvent) auditEvent).getActivityName()+":    "+((temp !=null)?temp[0]: temp));
		    	}
		    	
		    }catch(Exception e){
		    	e.printStackTrace();
		    }
		    System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++");
		} else if(auditEvent instanceof TransitionAuditEvent) {
			//Transition data
		    System.out.println(auditEvent.toString());
		}
	}
	
}